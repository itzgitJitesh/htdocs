<!DOCTYPE html>
<html>
<head>
    <title>Page Not Found</title>
</head>
<body>
<?php include'./views/partials/header.php';?>
    <h1>404 - Page Not Found</h1>
    <p>The page you are looking for does not exist.</p>
    <?php include'./views/partials/footer.php';?>
</body>
</html>
