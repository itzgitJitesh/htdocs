<footer>
        <p class="p-3 bg-dark text-white text-center">@WorldLensAdventures<br><br>
        <a href="https://www.facebook.com/earthtrekkers" class="fa fa-facebook"></a>
        <a href="https://www.earthtrekkers.com/travel-photography/#" class="fa fa-google"></a>
        <a href="https://www.youtube.com/channel/UCX9EU_QFjUKdfRI-Tlle_iQ" class="fa fa-youtube"></a>
        <a href="https://www.instagram.com/earthtrekkers/" class="fa fa-instagram"></a>
        <a href="https://www.pinterest.com/earthtrekkers/" class="fa fa-pinterest"></a>
    </p>
        
    </footer>