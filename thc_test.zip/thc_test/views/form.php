<hr>
<hr>
<br>
<center><p>Ready to embark on your next adventure? Contact us now and let's capture your journey together!</p></center>
<br>
<hr>
<hr>

        <section class="my-5 text-white section-dark bg-dark">
            <div class="py-5">
                <h2 class="text-center">Contacts</h2>
            </div>
            <div class="w-50 m-auto">
                <form action="userinfo.php" method="post" onsubmit="return myfunction()">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="user" autocomplete="off" class="form-control" id='user'>
                    </div>
                    <div class="form-group">
                        <label>Email-Id</label>
                        <input type="text" name="email" autocomplete="off" class="form-control" id='email'>
                    </div>
                    <div class="form-group">
                        <label>Mobile no.</label>
                        <input type="text" name="mobile" autocomplete="off" class="form-control" id='mobile'>
                    </div>
                    <div class="form-group">
                        <label>Comments</label>
                        <textarea class="form-control" name="comment"></textarea>
                    </div>
                    <div class="remember-forgot">
                        <label><input type="checkbox"> I agree to the terms and conditions</label>
                    </div>
                    <button type="submit" class="btn btn-success active">Submit</button>
                    <br><br><br><br>
                </form>
            </div>
        </section>