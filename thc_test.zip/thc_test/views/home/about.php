<section class="my-5">
        <div class="py-5">
            <h2 class="text-center" >About Us</h2>
        </div>
        <br>
        <br>
        <div class="container-fluid"></div>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-12">
                    <img src="./images/samp.jpg" alt="" class="img-fluid aboutimg">
                </div>
                <div class="col-lg-6 col-md-6 <col-12></col-12">
                    <h2 class="display-5">Hello there!</h2>
                    <br>
                    <br>
                    <p py-4>
                    I'm a friendly travel photographer and tour guide. With a keen eye and a love for exploration, I capture the essence of each country, weaving stories through my lens. Join me on a visual journey that brings the world's wonders to life  by capturing its essence through breathtaking photography. Explore, experience, and capture the world with us.
                    </p>
                    <a href="about.php" class="btn btn-success">Know more</a>
                </div>
            </div>
        </div>
    </section>