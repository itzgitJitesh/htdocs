<section class="my-5">
            <div class="py-5">
                <h2 class="text-center">Our Gallery</h2>
                <h1 class="text-trans-none blue-text word-spacing-15 xxlarge-title animated text-center">
        <span class="txt-rotate" data-period="300" data-rotate='["Hello", "नमस्ते", "Nǐ hǎo", "Halo", "Hola", "Ciao"]'>
            <span class="wrap">Nǐ </span>
        </span>
    </h1>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px"  alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" width="100%" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" width="100%" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px"  alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px"  width="100%" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" alt="" class="img-fluid pb-4">
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <img src="./images/samp.jpg" height="250px" alt="" class="img-fluid pb-4">
                    </div>
                </div>
            </div>
        </section>